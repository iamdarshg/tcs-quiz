# TCS Quiz 2026 Study Portal Design

## Goal

Adapt the CLAT GK portal into a standalone, no-login study site for the 2026 TCS Quiz roadmap. The original CLAT project and the user's personal web site are out of scope.

## Product decisions

- Ship as a separate static repository/site named `tcs-quiz-2026`.
- Keep the original portal's useful features: section navigation, search, topic maps, corpus map, personal map, dark theme, local read tracking, filters, and a scored quiz engine.
- Keep all personal data in browser storage. Provide JSON backup and restore rather than an unauthenticated hosted sync service.
- Make short-form fact learning and retrieval practice the primary workflow; include a coherent five-question Deep Module Set.

## Roadmap coverage

The dashboard must expose exactly these 15 modules, in roadmap order:

1. Computing History and Foundations
2. Software, Operating Systems, Languages and Databases
3. Internet, Web, Networking, Telecom and Mobile
4. Technology Companies, Personalities, Brands and Products
5. Artificial Intelligence, Data, Cloud, Automation, Robotics and Biometrics
6. Hardware, Semiconductors, Architectures and Quantum Computing
7. Cybersecurity, Malware, Privacy and Global Outages
8. Indian Digital Ecosystem and Indigenous Technology
9. Tata Group and TCS
10. Technology Across Industries and Culture
11. Science, Medicine and Mathematics Through Innovation
12. Engineering, Architecture, Infrastructure, Energy and Climate Technology
13. Space, Satellites, Defence and Frontier Technology
14. Current Technology, Science and Business Affairs
15. General-Awareness Safety Net

## Information architecture

`data/modules/index.json` is the manifest. Each module file supplies ranked fact cards, connection-map nodes, and MCQ questions. A shared normalizer keeps legacy month/static data readable while adding module-specific fields. Modules are the primary sections; the prior current/static labels are not exposed in the TCS navigation.

Each fact card includes an exam relevance score, a concise hook, expandable explainer, tags, map links, and questions. The required minimum content shape is six ranked facts and ten MCQs per module, giving every module a working drill pool while retaining the data model for expansion.

## Experience

The home page is an exam-readiness dashboard: overall completion, all fifteen module tiles, recent activity, weak-topic count, and a next-review queue. Module pages show filterable ranked cards, quick fact review, map access, and a module test action. A new Revision page assembles spaced review prompts from missed questions and cards last seen at least one day ago.

The quiz setup offers Rapid MCQ, Timed Module Test, Mixed Mock, and Deep Module Set modes. It supports module, topic, difficulty, count, and time-limit filters. Results score answers, explain each answer, record misses, and make those misses eligible for revision.

## Data ownership, backup, and errors

Progress, response history, and review state use a `tcsquiz.` localStorage namespace, separate from `clatgk.`. Backup exports a versioned JSON payload; restore validates its shape and refuses incompatible/corrupt files without overwriting existing data. Fetch failures show a recoverable in-app error with a retry action.

## Verification

Run the manifest validator, Node unit tests for the pure data/progress/quiz helpers, and an HTTP-server smoke check that verifies the manifest lists 15 modules and every module file loads.
